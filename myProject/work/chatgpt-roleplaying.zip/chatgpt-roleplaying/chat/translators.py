# chat/translators.py

from typing import Literal

import requests
from bs4 import BeautifulSoup


def google_translate(
    text: str,
    source: Literal["auto", "en", "ko"],    # 받을 type지정
    target: Literal["en", "ko"],
) -> str:

    text = text.strip()
    if not text:
        return ""

    endpoint_url = "https://translate.google.com/m"

    # translate.google.com/m/ 모바일 페이지의 요청내역을 흉내내기
    params = {
        "sl": source,
        "tl": target,
        "q": text,
        "ie": "UTF-8",
        "prev": "_m",
    }

    # Android 디바이스의 User-Agent를 흉내냅니다.
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/86.0.4240.183 Mobile Safari/537.36"
        ),
    }

    res = requests.get(
        endpoint_url,
        params=params,
        headers=headers,
        timeout=5,
    )
    res.raise_for_status()

    soup = BeautifulSoup(res.text, "html.parser")
    translated_text = soup.select_one(".result-container").text.strip()

    return translated_text